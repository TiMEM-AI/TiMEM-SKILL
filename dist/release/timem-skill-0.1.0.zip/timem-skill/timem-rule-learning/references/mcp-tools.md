# TiMEM MCP rule-learning tools

Full parameter reference for the 8 public rule-learning tools exposed by
[timem-mcp](https://github.com/TiMEM-AI/timem-mcp). This file is **self-contained**
— unlike the memory skills, `timem-rule-learning` does not depend on `skills/shared`.

All tools scope by **`user_id` + `agent_id`**: omit `user_id` (resolved from API Key);
pass one stable `agent_id` per agent role (default `"default"`). Backend: `/api/v1/rules/*`.

Core loop tools (`learn_rule`, `recall_rules`, `record_rule_outcome`, `update_rule`) may take
up to ~120 s — they invoke backend LLM paths.

All structured arguments must keep their native MCP JSON types. Pass `attributes` and
`filters` as objects/maps and tag/key collections as arrays. Never call `JSON.stringify`
or put JSON text inside a string. For example,
`attributes={"project": "timem-mcp"}` is valid, while
`attributes="{\"project\":\"timem-mcp\"}"` is a compatibility-only form that MCP and the
platform API normalize. Agents must not generate the encoded form. Malformed JSON or a
value that decodes to the wrong shape is rejected before business logic runs.

---

## `recall_rules`

Recall rules from one caller-owned retrieval query. Call it once on every user turn before
the first substantive response or action; empty result is normal.

| Parameter | Required | Notes |
|-----------|----------|-------|
| `query_text` | **Yes** | One concise retrieval query (1–4000 chars) |
| `judge_scene_text` | No | Decision scene for `judged` / `auto` (max 4000 chars) |
| `judge_context_text` | No | Evidence or longer context for `judged` / `auto` (max 30000 chars) |
| `agent_id` | Recommended | Stable role id |
| `mode` | No | `similarity` (default, retrieval only) / `judged` (complete filtered pool) / `auto` (retrieve `top_k`, then judge with fallback) |
| `top_k` | No | Default 5 (1–50) |
| `tags_hint` | No | Native array of up to 32 tags; biases retrieval without hard-filtering |
| `filters` | No | Native object/map of exact-match scalar attributes; max 16 keys / 8 KiB; never stringify |
| `include_missing_filter_keys` | No | Native array of up to 32 filter keys that should NOT exclude rules lacking that attribute |

```
recall_rules(
  query_text="linear history rules for merging a PR into main",
  judge_scene_text="merge PR into main branch",
  judge_context_text="repo timem-mcp, PR #92",
  agent_id="coder",
  mode="judged",
  top_k=5,
)
```

Results include each rule's `rule_id` — keep it for `record_rule_outcome`. The aggregate
retrieval field is `retrieval_score`; route/rank, fallback, applicability, evidence, and
`judgement` fields may also be present.

---

## `learn_rule`

Create a reusable rule from a situation and its verified outcome.

| Parameter | Required | Notes |
|-----------|----------|-------|
| `situation_text` | **Yes** | Observable trigger **before** the decision; 1–4000 chars |
| `outcome_text` | **Yes** | Verified result + the reusable lesson; 1–4000 chars |
| `agent_id` | Recommended | Stable role id |
| `suggested_tags` | No | Native array of up to 32 short topical tags in the input's primary language; for Chinese input, use Chinese for ordinary concepts and keep English only for established technical terms, names, acronyms, commands, or code identifiers |
| `attributes` | No | Native object/map of stable keys (`project`, `domain`, `stage`) for recall-time filtering; max 32 top-level keys / 16 KiB; never stringify |

With backend governance disabled by default, ordinary calls return `action="created"` and
`merged_into=null`. Temporarily do not run recall/list solely to judge duplicates before
learning; call `learn_rule` directly for each verified lesson.

---

## `record_rule_outcome`

Grade a rule after it actually influenced an action and the result is known.

| Parameter | Required | Notes |
|-----------|----------|-------|
| `rule_id` | **Yes** | From `recall_rules` results |
| `helpful` | **Yes** | `false` if the rule misled, did not apply, or needed an exception |
| `note` | Recommended | 1–2 sentences of evidence; for `helpful=false` describe the exception |
| `triggered_refine` | No | Default `true` — allow the backend to revise the rule |

---

## `update_rule`

Patch rule metadata or manually revise its text. At least one update field is required.

| Parameter | Required | Notes |
|-----------|----------|-------|
| `rule_id` | **Yes** | Rule to update |
| `manual_situation` | No | Revised trigger; **re-embedded** — changes future recall matching |
| `manual_lesson` | No | Revised lesson text only |
| `attributes` | No | Native object/map, **merged** key-by-key by default; never stringify |
| `replace_attributes` | No | `true` overwrites the whole attributes mapping |
| `trigger_tags` | No | Native array that **replaces** the whole tag set |
| `name` / `is_enabled` / `status` | No | Metadata curation; status: `active`, `archived`, `disabled`, `pending_review`, `deprecated`, `superseded` |

---

## `list_rules`

List rules in a `user_id` + `agent_id` scope.

| Parameter | Required | Notes |
|-----------|----------|-------|
| `page` / `page_size` | No | Defaults 1 / 20 (max 100) |
| `status` / `is_enabled` | No | Lifecycle filters |
| `tags` | No | Tag filter |
| `attr_key` + `attr_value` | No | Single attribute filter |
| `min_helpful_rate` | No | 0.0–1.0 |
| `sort` | No | `last_used_at_desc` (default), `created_at_desc`, `usage_count_desc`, `helpful_rate_desc` |

---

## `get_rule` / `delete_rule`

`get_rule(rule_id)` — fetch one rule. `delete_rule(rule_id)` — **archive** (soft delete), on
explicit user intent only; locate the id via `list_rules` / `recall_rules` first.

---

## `get_rule_usage_report`

Read-only usage for the authenticated user. The tool does not accept `user_id`.

| Parameter | Required | Notes |
|-----------|----------|-------|
| `breakdown` | No | `summary` (default) or `daily` |
| `start_date` / `end_date` | No | Inclusive `YYYY-MM-DD` range |
| `agent_id` | No | Stable role filter; omit for all of the user's agents |
| `operation` | No | `learn` or `recall` |

`recall_billable_tokens` equals embedding tokens plus judge-model total tokens.

---

## Server-side companions

| Type | Name | Use |
|------|------|-----|
| Resource | `timem://guides/rule-learning` | Server-side loop guide |
| Prompt | `rule_task_start` | Prepare the mandatory recall before responding or acting |
| Prompt | `rule_session_wrap_up` | Grade applied rules + run LEARN EVAL; conditionally learn 0–3 rules |
